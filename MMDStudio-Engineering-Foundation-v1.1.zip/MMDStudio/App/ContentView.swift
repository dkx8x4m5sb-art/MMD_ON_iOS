import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject private var modelStore: ModelStore
    @State private var showingImporter = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                MetalPreview(model: modelStore.model)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color.black)

                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(modelStore.model?.header.nameJP ?? "No model loaded")
                                .font(.headline)
                                .lineLimit(1)
                            Text(modelStore.status)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button { showingImporter = true } label: {
                            Label("Import PMX", systemImage: "square.and.arrow.down")
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    if let model = modelStore.model {
                        Grid(alignment: .leading, horizontalSpacing: 18, verticalSpacing: 6) {
                            GridRow { Text("PMX"); Text(String(format: "%.2f", model.header.version)) }
                            GridRow { Text("Vertices"); Text(model.vertices.count.formatted()) }
                            GridRow { Text("Triangles"); Text((model.indices.count / 3).formatted()) }
                            GridRow { Text("Materials"); Text(model.materials.count.formatted()) }
                        }
                        .font(.caption)
                    }
                }
                .padding()
                .background(.regularMaterial)
            }
            .navigationTitle("MMD Studio")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showingImporter = true } label: { Image(systemName: "plus") }
                }
            }
            .fileImporter(isPresented: $showingImporter,
                          allowedContentTypes: [.data],
                          allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    guard let url = urls.first else { return }
                    modelStore.importPMX(from: url)
                case .failure(let error):
                    modelStore.status = "Import failed: \(error.localizedDescription)"
                }
            }
        }
    }
}
