import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject private var modelStore: ModelStore
    @State private var showingImporter = false
    @State private var yaw: Float = 0
    @State private var pitch: Float = 0
    @State private var zoom: Float = 1
    @State private var dragOrigin = CGSize.zero
    @State private var zoomOrigin: Float = 1

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ZStack(alignment: .topTrailing) {
                    MetalPreview(model: modelStore.model,
                                 yaw: $yaw, pitch: $pitch, zoom: $zoom)
                        .background(Color.black)
                        .contentShape(Rectangle())
                        .gesture(
                            DragGesture()
                                .onChanged { value in
                                    yaw = Float(value.translation.width) * 0.008
                                    pitch = Float(value.translation.height) * 0.008
                                }
                                .onEnded { _ in
                                    dragOrigin = .zero
                                }
                        )
                        .simultaneousGesture(
                            MagnificationGesture()
                                .onChanged { value in
                                    zoom = min(max(zoomOrigin * Float(value), 0.25), 4.0)
                                }
                                .onEnded { _ in zoomOrigin = zoom }
                        )

                    VStack(spacing: 8) {
                        controlButton("arrow.counterclockwise", help: "重置视角") {
                            yaw = 0
                            pitch = 0
                            zoom = 1
                            zoomOrigin = 1
                        }
                        controlButton("plus.magnifyingglass", help: "放大") {
                            zoom = min(zoom * 1.2, 4)
                            zoomOrigin = zoom
                        }
                        controlButton("minus.magnifyingglass", help: "缩小") {
                            zoom = max(zoom / 1.2, 0.25)
                            zoomOrigin = zoom
                        }
                    }
                    .padding(12)
                }

                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(modelStore.model?.header.nameJP ?? "未加载模型")
                                .font(.headline)
                                .lineLimit(1)
                            Text(modelStore.status)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(2)
                        }
                        Spacer()
                        Button { showingImporter = true } label: {
                            Label("导入 PMX", systemImage: "square.and.arrow.down")
                        }
                        .buttonStyle(.borderedProminent)
                    }

                    if let model = modelStore.model {
                        HStack(spacing: 16) {
                            metric("顶点", model.vertices.count)
                            metric("三角面", model.indices.count / 3)
                            metric("材质", model.materials.count)
                            metric("纹理", model.textures.count)
                        }
                    } else {
                        Text("导入 PMX 文件即可预览模型。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding()
                .background(.regularMaterial)
            }
            .navigationTitle("MMD Studio")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showingImporter = true } label: {
                        Image(systemName: "plus")
                    }
                    .accessibilityLabel("导入 PMX 模型")
                }
            }
            .fileImporter(
                isPresented: $showingImporter,
                allowedContentTypes: [.data],
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    guard let url = urls.first else { return }
                    yaw = 0
                    pitch = 0
                    zoom = 1
                    zoomOrigin = 1
                    modelStore.importPMX(from: url)
                case .failure(let error):
                    modelStore.status = "导入失败：\(error.localizedDescription)"
                }
            }
        }
    }

    private func controlButton(_ symbol: String, help: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 15, weight: .semibold))
                .frame(width: 38, height: 38)
                .background(.ultraThinMaterial, in: Circle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(help)
    }

    private func metric(_ title: String, _ value: Int) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value.formatted())
                .font(.system(.subheadline, design: .rounded, weight: .semibold))
                .monospacedDigit()
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }
}
