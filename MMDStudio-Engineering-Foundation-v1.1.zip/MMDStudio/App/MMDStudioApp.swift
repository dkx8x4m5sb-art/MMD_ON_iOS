import SwiftUI

@main
struct MMDStudioApp: App {
    @StateObject private var modelStore = ModelStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(modelStore)
                .preferredColorScheme(.dark)
        }
    }
}
