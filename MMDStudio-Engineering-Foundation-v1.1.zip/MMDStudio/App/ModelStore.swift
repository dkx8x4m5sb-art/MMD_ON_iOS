import Foundation
import SwiftUI

@MainActor
final class ModelStore: ObservableObject {
    @Published var model: PMXModel?
    @Published var status = "Ready — import a PMX model"

    func importPMX(from url: URL) {
        let hasAccess = url.startAccessingSecurityScopedResource()
        defer {
            if hasAccess { url.stopAccessingSecurityScopedResource() }
        }

        do {
            let data = try Data(contentsOf: url, options: [.mappedIfSafe])
            model = try PMXModelReader.read(data)
            status = "Loaded \(model?.vertices.count ?? 0) vertices · \(model?.materials.count ?? 0) materials"
        } catch {
            model = nil
            status = "PMX read error: \(error.localizedDescription)"
        }
    }
}
