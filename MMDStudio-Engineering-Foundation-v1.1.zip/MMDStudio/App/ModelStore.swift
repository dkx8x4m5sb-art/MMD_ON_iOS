import Foundation
import SwiftUI
import UIKit
import os

@MainActor
final class ModelStore: ObservableObject {
    @Published var model: PMXModel?
    @Published var textures: [Int: UIImage] = [:]
    @Published var status = "就绪 — 请导入模型"
    @Published var lastError: String?

    private let log = Logger(subsystem: "com.mmdstudio.app", category: "ModelImport")

    /// 支持三种入口：.pmx 单文件、模型文件夹、包含模型的 .zip
    func importPackage(from url: URL) {
        lastError = nil
        status = "正在读取模型包…"
        log.info("用户选中：\(url.lastPathComponent, privacy: .public)")

        // 文件/文件夹选择器返回安全作用域 URL；解压与贴图读取都必须在作用域内完成
        let scoped = url.startAccessingSecurityScopedResource()
        defer {
            if scoped { url.stopAccessingSecurityScopedResource() }
        }
        if !scoped {
            log.warning("startAccessingSecurityScopedResource 返回 false，仍尝试直接读取")
        }

        do {
            let package = try ModelPackageLoader.load(from: url)
            model = package.model
            textures = package.textures
            lastError = nil

            let totalTextures = package.model.textures.count
            var summary = "已载入 \(package.model.vertices.count) 个顶点 · \(package.model.materials.count) 个材质"
            if totalTextures > 0 {
                summary += " · 贴图 \(package.textures.count)/\(totalTextures)"
            }
            if !package.warnings.isEmpty {
                summary += " · 警告 \(package.warnings.count)"
                for warning in package.warnings {
                    log.warning("\(warning, privacy: .public)")
                }
            }
            status = summary
            log.info("解析成功：\(package.pmxURL.lastPathComponent, privacy: .public)，顶点 \(package.model.vertices.count, privacy: .public)，贴图 \(package.textures.count, privacy: .public)")
        } catch {
            fail("\(describe(error))")
        }
    }

    /// 文件选择器本身失败（例如 iCloud 未登录、权限拒绝）
    func reportPickerFailure(_ error: Error) {
        fail("文件选择失败：\(describe(error))")
    }

    /// 选择结果为空，或系统没有回调可用 URL
    func reportNoSelection() {
        fail("没有取得所选内容，请重试")
    }

    private func fail(_ reason: String) {
        status = "导入失败：\(reason)"
        lastError = status
        log.error("\(reason, privacy: .public)")
    }

    /// 把系统错误补上 domain/code，便于定位是权限、iCloud 还是解析问题
    private func describe(_ error: Error) -> String {
        let ns = error as NSError
        if ns.domain == NSCocoaErrorDomain || ns.domain == NSPOSIXErrorDomain {
            return "\(error.localizedDescription)（\(ns.domain) \(ns.code)）"
        }
        return error.localizedDescription
    }
}
