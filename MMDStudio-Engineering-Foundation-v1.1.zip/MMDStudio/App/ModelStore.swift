import Foundation
import SwiftUI

@MainActor
final class ModelStore: ObservableObject {
    @Published var model: PMXModel?
    @Published var status = "就绪 — 请导入 PMX 模型"

    func importPMX(from url: URL) {
        let hasAccess = url.startAccessingSecurityScopedResource()
        defer {
            if hasAccess { url.stopAccessingSecurityScopedResource() }
        }

        do {
            let data = try Data(contentsOf: url, options: [.mappedIfSafe])
            model = try PMXModelReader.read(data)
            status = "已载入 \(model?.vertices.count ?? 0) 个顶点 · \(model?.materials.count ?? 0) 个材质"
        } catch {
            model = nil
            status = "PMX 读取失败：\(error.localizedDescription)"
        }
    }
}
