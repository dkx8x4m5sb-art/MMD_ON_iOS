#include <metal_stdlib>
using namespace metal;

struct VertexIn {
    float3 position [[attribute(0)]];
    float3 normal [[attribute(1)]];
    float2 uv [[attribute(2)]];
};

struct VertexOut {
    float4 position [[position]];
    float3 normal;
};

vertex VertexOut mmd_vertex(VertexIn in [[stage_in]]) {
    VertexOut out;
    // Initial diagnostic camera transform. A perspective camera replaces this in the camera milestone.
    out.position = float4(in.position.x * 0.55, in.position.y * 0.55, 0.5 + in.position.z * 0.05, 1.0);
    out.normal = normalize(in.normal);
    return out;
}

fragment float4 mmd_fragment(VertexOut in [[stage_in]]) {
    float light = max(dot(normalize(in.normal), normalize(float3(0.3, 0.8, 0.5))), 0.18);
    return float4(float3(0.72, 0.76, 0.84) * light, 1.0);
}
