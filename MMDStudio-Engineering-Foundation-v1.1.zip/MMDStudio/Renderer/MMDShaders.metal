#include <metal_stdlib>
using namespace metal;

struct VertexIn {
    float3 position [[attribute(0)]];
    float3 normal [[attribute(1)]];
    float2 uv [[attribute(2)]];
};

struct CameraUniforms {
    float yaw;
    float pitch;
    float zoom;
    float padding;
};

struct MaterialUniforms {
    float4 diffuse;     // 0
    float hasTexture;   // 16
    float pad0;         // 20
    float pad1;         // 24
    float pad2;         // 28
};

struct VertexOut {
    float4 position [[position]];
    float3 normal;
    float2 uv;
};

vertex VertexOut mmd_vertex(VertexIn in [[stage_in]],
                            constant CameraUniforms& camera [[buffer(1)]]) {
    VertexOut out;

    float cy = cos(camera.yaw);
    float sy = sin(camera.yaw);
    float cp = cos(camera.pitch);
    float sp = sin(camera.pitch);

    float3 p = in.position;
    float3 rotated = float3(
        cy * p.x + sy * p.z,
        -sy * sp * p.x + cp * p.y + cy * sp * p.z,
        -sy * cp * p.x - sp * p.y + cy * cp * p.z
    );

    float3 n = in.normal;
    out.normal = normalize(float3(
        cy * n.x + sy * n.z,
        -sy * sp * n.x + cp * n.y + cy * sp * n.z,
        -sy * cp * n.x - sp * n.y + cy * cp * n.z
    ));

    out.position = float4(rotated.x * 0.58 * camera.zoom,
                          rotated.y * 0.58 * camera.zoom,
                          0.5 + rotated.z * 0.08,
                          1.0);
    out.uv = in.uv;
    return out;
}

fragment float4 mmd_fragment(VertexOut in [[stage_in]],
                             constant MaterialUniforms& material [[buffer(0)]],
                             texture2d<float> diffuseTexture [[texture(0)]]) {
    constexpr sampler textureSampler(filter::linear, address::repeat);

    float3 normal = normalize(in.normal);
    float3 lightDirection = normalize(float3(0.3, 0.8, 0.5));
    float lighting = max(dot(normal, lightDirection), 0.20);

    float4 baseColor = material.diffuse;
    if (material.hasTexture > 0.5) {
        baseColor *= diffuseTexture.sample(textureSampler, in.uv);
    }

    return float4(baseColor.rgb * lighting, baseColor.a);
}
