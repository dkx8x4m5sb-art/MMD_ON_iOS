import SwiftUI
import MetalKit

struct MetalPreview: UIViewRepresentable {
    let model: PMXModel?

    func makeUIView(context: Context) -> MTKView {
        let view = MTKView(frame: .zero, device: MTLCreateSystemDefaultDevice())
        view.clearColor = MTLClearColor(red: 0.055, green: 0.065, blue: 0.085, alpha: 1)
        view.colorPixelFormat = .bgra8Unorm
        view.depthStencilPixelFormat = .depth32Float
        view.delegate = context.coordinator
        view.preferredFramesPerSecond = 60
        context.coordinator.attach(view: view)
        context.coordinator.update(model: model)
        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {
        context.coordinator.update(model: model)
    }

    func makeCoordinator() -> PreviewRenderer { PreviewRenderer() }
}

private struct GPUVertex {
    var position: SIMD3<Float>
    var normal: SIMD3<Float>
    var uv: SIMD2<Float>
}

final class PreviewRenderer: NSObject, MTKViewDelegate {
    private var device: MTLDevice?
    private var commandQueue: MTLCommandQueue?
    private var pipeline: MTLRenderPipelineState?
    private var depthState: MTLDepthStencilState?
    private var vertexBuffer: MTLBuffer?
    private var indexBuffer: MTLBuffer?
    private var indexCount = 0

    func attach(view: MTKView) {
        guard let device = view.device else { return }
        self.device = device
        commandQueue = device.makeCommandQueue()

        let library = device.makeDefaultLibrary()
        if let library,
           let vertex = library.makeFunction(name: "mmd_vertex"),
           let fragment = library.makeFunction(name: "mmd_fragment") {
            let descriptor = MTLRenderPipelineDescriptor()
            descriptor.vertexFunction = vertex
            descriptor.fragmentFunction = fragment
            descriptor.colorAttachments[0].pixelFormat = view.colorPixelFormat
            descriptor.depthAttachmentPixelFormat = view.depthStencilPixelFormat

            let layout = MTLVertexDescriptor()
            layout.attributes[0].format = .float3
            layout.attributes[0].offset = 0
            layout.attributes[0].bufferIndex = 0
            layout.attributes[1].format = .float3
            layout.attributes[1].offset = MemoryLayout<SIMD3<Float>>.stride
            layout.attributes[1].bufferIndex = 0
            layout.attributes[2].format = .float2
            layout.attributes[2].offset = MemoryLayout<SIMD3<Float>>.stride * 2
            layout.attributes[2].bufferIndex = 0
            layout.layouts[0].stride = MemoryLayout<GPUVertex>.stride
            descriptor.vertexDescriptor = layout
            pipeline = try? device.makeRenderPipelineState(descriptor: descriptor)
        }

        let depth = MTLDepthStencilDescriptor()
        depth.depthCompareFunction = .lessEqual
        depth.isDepthWriteEnabled = true
        depthState = device.makeDepthStencilState(descriptor: depth)
    }

    func update(model: PMXModel?) {
        guard let model, let device else {
            vertexBuffer = nil
            indexBuffer = nil
            indexCount = 0
            return
        }
        guard !model.vertices.isEmpty, !model.indices.isEmpty else { return }

        let minV = model.vertices.reduce(SIMD3<Float>(repeating: .greatestFiniteMagnitude)) {
            SIMD3(min($0.x, $1.position.x), min($0.y, $1.position.y), min($0.z, $1.position.z))
        }
        let maxV = model.vertices.reduce(SIMD3<Float>(repeating: -.greatestFiniteMagnitude)) {
            SIMD3(max($0.x, $1.position.x), max($0.y, $1.position.y), max($0.z, $1.position.z))
        }
        let center = (minV + maxV) * 0.5
        let extent = max(max(maxV.x - minV.x, maxV.y - minV.y), max(maxV.z - minV.z, 0.001))
        let scale = 1.7 / extent

        let gpuVertices = model.vertices.map { v in
            GPUVertex(position: (v.position - center) * scale,
                      normal: v.normal, uv: v.uv)
        }
        vertexBuffer = device.makeBuffer(bytes: gpuVertices,
                                         length: gpuVertices.count * MemoryLayout<GPUVertex>.stride)
        indexBuffer = device.makeBuffer(bytes: model.indices,
                                        length: model.indices.count * MemoryLayout<UInt32>.stride)
        indexCount = model.indices.count
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

    func draw(in view: MTKView) {
        guard let pass = view.currentRenderPassDescriptor,
              let drawable = view.currentDrawable,
              let command = commandQueue?.makeCommandBuffer(),
              let encoder = command.makeRenderCommandEncoder(descriptor: pass)
        else { return }

        if let pipeline, let vertexBuffer, let indexBuffer, indexCount > 0 {
            encoder.setRenderPipelineState(pipeline)
            encoder.setDepthStencilState(depthState)
            encoder.setVertexBuffer(vertexBuffer, offset: 0, index: 0)
            encoder.drawIndexedPrimitives(type: .triangle,
                                          indexCount: indexCount,
                                          indexType: .uint32,
                                          indexBuffer: indexBuffer,
                                          indexBufferOffset: 0)
        }
        encoder.endEncoding()
        command.present(drawable)
        command.commit()
    }
}
