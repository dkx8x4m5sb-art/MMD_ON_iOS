import SwiftUI
import MetalKit
import UIKit

struct MetalPreview: UIViewRepresentable {
    let model: PMXModel?
    let textures: [Int: UIImage]
    @Binding var yaw: Float
    @Binding var pitch: Float
    @Binding var zoom: Float

    func makeUIView(context: Context) -> MTKView {
        let view = MTKView(frame: .zero, device: MTLCreateSystemDefaultDevice())
        view.clearColor = MTLClearColor(red: 0.055, green: 0.065, blue: 0.085, alpha: 1)
        view.colorPixelFormat = .bgra8Unorm
        view.depthStencilPixelFormat = .depth32Float
        view.framebufferOnly = true
        view.enableSetNeedsDisplay = false
        view.isPaused = false
        view.delegate = context.coordinator
        view.preferredFramesPerSecond = 60
        context.coordinator.attach(view: view)
        context.coordinator.update(model: model, textures: textures)
        context.coordinator.updateCamera(yaw: yaw, pitch: pitch, zoom: zoom)
        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {
        context.coordinator.update(model: model, textures: textures)
        context.coordinator.updateCamera(yaw: yaw, pitch: pitch, zoom: zoom)
    }

    func makeCoordinator() -> PreviewRenderer { PreviewRenderer() }
}

private struct GPUVertex {
    var position: SIMD3<Float>
    var normal: SIMD3<Float>
    var uv: SIMD2<Float>
}

private struct CameraUniforms {
    var yaw: Float
    var pitch: Float
    var zoom: Float
    var padding: Float = 0
}

private struct MaterialUniforms {
    var diffuse: SIMD4<Float>
    var hasTexture: Float
    var pad0: Float = 0
    var pad1: Float = 0
    var pad2: Float = 0
}

private struct DrawRange {
    let start: Int
    let count: Int
    let texture: MTLTexture?
    let diffuse: SIMD4<Float>
}

final class PreviewRenderer: NSObject, MTKViewDelegate {
    private var device: MTLDevice?
    private var commandQueue: MTLCommandQueue?
    private var pipeline: MTLRenderPipelineState?
    private var depthState: MTLDepthStencilState?
    private var vertexBuffer: MTLBuffer?
    private var indexBuffer: MTLBuffer?
    private var whiteTexture: MTLTexture?
    private var ranges: [DrawRange] = []
    private var modelSignature: String?
    private var uniforms = CameraUniforms(yaw: 0, pitch: 0, zoom: 1)

    func attach(view: MTKView) {
        guard let device = view.device else { return }
        self.device = device
        commandQueue = device.makeCommandQueue()
        whiteTexture = makeWhiteTexture(device: device)

        guard let library = device.makeDefaultLibrary(),
              let vertex = library.makeFunction(name: "mmd_vertex"),
              let fragment = library.makeFunction(name: "mmd_fragment") else {
            return
        }

        let descriptor = MTLRenderPipelineDescriptor()
        descriptor.vertexFunction = vertex
        descriptor.fragmentFunction = fragment
        descriptor.colorAttachments[0].pixelFormat = view.colorPixelFormat
        descriptor.depthAttachmentPixelFormat = view.depthStencilPixelFormat

        descriptor.colorAttachments[0].isBlendingEnabled = true
        descriptor.colorAttachments[0].rgbBlendOperation = .add
        descriptor.colorAttachments[0].alphaBlendOperation = .add
        descriptor.colorAttachments[0].sourceRGBBlendFactor = .sourceAlpha
        descriptor.colorAttachments[0].sourceAlphaBlendFactor = .sourceAlpha
        descriptor.colorAttachments[0].destinationRGBBlendFactor = .oneMinusSourceAlpha
        descriptor.colorAttachments[0].destinationAlphaBlendFactor = .oneMinusSourceAlpha

        let layout = MTLVertexDescriptor()
        layout.attributes[0].format = .float3
        layout.attributes[0].offset = 0
        layout.attributes[0].bufferIndex = 0
        layout.attributes[1].format = .float3
        layout.attributes[1].offset = MemoryLayout<SIMD3<Float>>.stride
        layout.attributes[1].bufferIndex = 0
        layout.attributes[2].format = .float2
        layout.attributes[2].offset = MemoryLayout<SIMD3<Float>>.stride * 2
        layout.attributes[2].bufferIndex = 0
        layout.layouts[0].stride = MemoryLayout<GPUVertex>.stride
        descriptor.vertexDescriptor = layout

        pipeline = try? device.makeRenderPipelineState(descriptor: descriptor)

        let depth = MTLDepthStencilDescriptor()
        depth.depthCompareFunction = .lessEqual
        depth.isDepthWriteEnabled = true
        depthState = device.makeDepthStencilState(descriptor: depth)
    }

    func updateCamera(yaw: Float, pitch: Float, zoom: Float) {
        uniforms.yaw = yaw
        uniforms.pitch = min(max(pitch, -1.45), 1.45)
        uniforms.zoom = min(max(zoom, 0.25), 4.0)
    }

    func update(model: PMXModel?, textures: [Int: UIImage]) {
        guard let model, let device else {
            vertexBuffer = nil
            indexBuffer = nil
            ranges = []
            modelSignature = nil
            return
        }
        guard !model.vertices.isEmpty, !model.indices.isEmpty else {
            vertexBuffer = nil
            indexBuffer = nil
            ranges = []
            modelSignature = nil
            return
        }

        // SwiftUI 在拖动/缩放时也会调用 updateUIView；模型没变就不要重复上传顶点和贴图
        let signature = "\(model.header.nameJP)|\(model.vertices.count)|\(model.indices.count)|\(model.materials.count)|\(model.textures.count)|\(textures.count)"
        if signature == modelSignature { return }
        modelSignature = signature

        let minV = model.vertices.reduce(SIMD3<Float>(repeating: .greatestFiniteMagnitude)) {
            SIMD3(min($0.x, $1.position.x), min($0.y, $1.position.y), min($0.z, $1.position.z))
        }
        let maxV = model.vertices.reduce(SIMD3<Float>(repeating: -.greatestFiniteMagnitude)) {
            SIMD3(max($0.x, $1.position.x), max($0.y, $1.position.y), max($0.z, $1.position.z))
        }
        let center = (minV + maxV) * 0.5
        let extent = max(max(maxV.x - minV.x, maxV.y - minV.y), max(maxV.z - minV.z, 0.001))
        let scale = 1.65 / extent

        let gpuVertices = model.vertices.map { vertex in
            GPUVertex(position: (vertex.position - center) * scale,
                      normal: vertex.normal,
                      uv: vertex.uv)
        }
        vertexBuffer = device.makeBuffer(
            bytes: gpuVertices,
            length: gpuVertices.count * MemoryLayout<GPUVertex>.stride
        )
        indexBuffer = device.makeBuffer(
            bytes: model.indices,
            length: model.indices.count * MemoryLayout<UInt32>.stride
        )

        // 纹理按 PMX 的 textureIndex 对应；加载失败的索引在字典里没有条目，退回材质纯色
        var metalTextures: [MTLTexture?] = Array(repeating: nil, count: model.textures.count)
        if !textures.isEmpty {
            let loader = MTKTextureLoader(device: device)
            let options: [MTKTextureLoader.Option: Any] = [
                .SRGB: NSNumber(value: false),
                .textureUsage: NSNumber(value: MTLTextureUsage.shaderRead.rawValue),
                .textureStorageMode: NSNumber(value: MTLStorageMode.private.rawValue)
            ]
            for (index, image) in textures where index >= 0 && index < metalTextures.count {
                guard let cgImage = image.cgImage else { continue }
                metalTextures[index] = try? loader.newTexture(cgImage: cgImage, options: options)
            }
        }

        var builtRanges: [DrawRange] = []
        builtRanges.reserveCapacity(model.materials.count + 1)
        var start = 0
        for material in model.materials {
            let remaining = model.indices.count - start
            guard remaining > 0 else { break }
            let count = max(0, min(material.surfaceCount, remaining))
            guard count > 0 else { continue }
            let texture: MTLTexture?
            if material.textureIndex >= 0, material.textureIndex < metalTextures.count {
                texture = metalTextures[material.textureIndex]
            } else {
                texture = nil
            }
            builtRanges.append(DrawRange(start: start, count: count,
                                         texture: texture, diffuse: material.diffuse))
            start += count
        }
        if start < model.indices.count {
            builtRanges.append(DrawRange(start: start, count: model.indices.count - start,
                                         texture: nil,
                                         diffuse: SIMD4<Float>(0.78, 0.81, 0.88, 1)))
        }
        ranges = builtRanges
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

    func draw(in view: MTKView) {
        guard let pass = view.currentRenderPassDescriptor,
              let drawable = view.currentDrawable,
              let command = commandQueue?.makeCommandBuffer(),
              let encoder = command.makeRenderCommandEncoder(descriptor: pass) else {
            return
        }

        if let pipeline, let vertexBuffer, let indexBuffer, !ranges.isEmpty {
            encoder.setRenderPipelineState(pipeline)
            encoder.setDepthStencilState(depthState)
            encoder.setCullMode(.none)
            encoder.setVertexBuffer(vertexBuffer, offset: 0, index: 0)
            var frameUniforms = uniforms
            encoder.setVertexBytes(&frameUniforms,
                                   length: MemoryLayout<CameraUniforms>.stride,
                                   index: 1)

            for range in ranges {
                var material = MaterialUniforms(diffuse: range.diffuse,
                                                hasTexture: range.texture == nil ? 0 : 1)
                encoder.setFragmentTexture(range.texture ?? whiteTexture, index: 0)
                encoder.setFragmentBytes(&material,
                                         length: MemoryLayout<MaterialUniforms>.stride,
                                         index: 0)
                encoder.drawIndexedPrimitives(
                    type: .triangle,
                    indexCount: range.count,
                    indexType: .uint32,
                    indexBuffer: indexBuffer,
                    indexBufferOffset: range.start * MemoryLayout<UInt32>.stride
                )
            }
        }
        encoder.endEncoding()
        command.present(drawable)
        command.commit()
    }

    private func makeWhiteTexture(device: MTLDevice) -> MTLTexture? {
        let descriptor = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: .rgba8Unorm, width: 1, height: 1, mipmapped: false)
        descriptor.usage = .shaderRead
        descriptor.storageMode = .shared
        guard let texture = device.makeTexture(descriptor: descriptor) else { return nil }
        var pixel: [UInt8] = [255, 255, 255, 255]
        pixel.withUnsafeBytes { buffer in
            guard let base = buffer.baseAddress else { return }
            texture.replace(region: MTLRegionMake2D(0, 0, 1, 1),
                            mipmapLevel: 0,
                            withBytes: base,
                            bytesPerRow: 4)
        }
        return texture
    }
}
