import Foundation
import simd

struct PMXVertex {
    var position: SIMD3<Float>
    var normal: SIMD3<Float>
    var uv: SIMD2<Float>
    var edgeScale: Float
}

struct PMXMaterial {
    let nameJP: String
    let nameEN: String
    let diffuse: SIMD4<Float>
    let specular: SIMD3<Float>
    let ambient: SIMD3<Float>
    let flags: UInt8
    let textureIndex: Int
    let sphereTextureIndex: Int
    let surfaceCount: Int
}

struct PMXModel {
    let header: PMXHeader
    let vertices: [PMXVertex]
    let indices: [UInt32]
    let textures: [String]
    let materials: [PMXMaterial]
}
