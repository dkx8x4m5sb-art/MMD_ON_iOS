import Foundation

private struct PMXCursor {
    let data: Data
    var offset = 0

    mutating func bytes(_ count: Int) throws -> [UInt8] {
        guard count >= 0, offset + count <= data.count else { throw PMXReadError.truncatedData }
        let result = Array(data[offset..<(offset + count)])
        offset += count
        return result
    }

    mutating func u8() throws -> UInt8 { try bytes(1)[0] }
    mutating func i8() throws -> Int8 { Int8(bitPattern: try u8()) }

    mutating func u16() throws -> UInt16 {
        let b = try bytes(2)
        return UInt16(b[0]) | UInt16(b[1]) << 8
    }

    mutating func i16() throws -> Int16 { Int16(bitPattern: try u16()) }

    mutating func u32() throws -> UInt32 {
        let b = try bytes(4)
        return UInt32(b[0]) | UInt32(b[1]) << 8 | UInt32(b[2]) << 16 | UInt32(b[3]) << 24
    }

    mutating func i32() throws -> Int32 { Int32(bitPattern: try u32()) }
    mutating func f32() throws -> Float { Float(bitPattern: try u32()) }

    mutating func index(size: UInt8, signed: Bool = false) throws -> Int {
        switch size {
        case 1:
            let v = try u8()
            return signed ? Int(Int8(bitPattern: v)) : Int(v)
        case 2:
            let v = try u16()
            return signed ? Int(Int16(bitPattern: v)) : Int(v)
        case 4:
            let v = try u32()
            return signed ? Int(Int32(bitPattern: v)) : Int(v)
        default:
            throw PMXReadError.invalidHeader
        }
    }

    mutating func vec2() throws -> SIMD2<Float> { SIMD2(try f32(), try f32()) }
    mutating func vec3() throws -> SIMD3<Float> { SIMD3(try f32(), try f32(), try f32()) }
    mutating func vec4() throws -> SIMD4<Float> { SIMD4(try f32(), try f32(), try f32(), try f32()) }

    mutating func string(encoding: UInt8) throws -> String {
        let length = try i32()
        guard length >= 0, length <= 64 * 1024 * 1024 else { throw PMXReadError.invalidStringLength }
        let raw = try bytes(Int(length))
        if encoding == 1 {
            guard let s = String(bytes: raw, encoding: .utf8) else { throw PMXReadError.invalidEncoding }
            return s
        }
        guard raw.count.isMultiple(of: 2) else { throw PMXReadError.invalidEncoding }
        let units = stride(from: 0, to: raw.count, by: 2).map { UInt16(raw[$0]) | UInt16(raw[$0 + 1]) << 8 }
        return String(decoding: units, as: UTF16.self)
    }
}

enum PMXModelReader {
    static func read(_ data: Data) throws -> PMXModel {
        var c = PMXCursor(data: data)
        guard try c.bytes(4) == Array("PMX ".utf8) else { throw PMXReadError.invalidSignature }
        let version = try c.f32()
        guard abs(version - 2.0) < 0.01 || abs(version - 2.1) < 0.01 else {
            throw PMXReadError.unsupportedVersion(version)
        }
        let globalCount = Int(try c.u8())
        guard globalCount == 8 else { throw PMXReadError.invalidHeader }
        let g = try c.bytes(globalCount)
        let encoding = g[0]
        guard encoding <= 1 else { throw PMXReadError.invalidEncoding }
        let header = PMXHeader(
            version: version, encoding: encoding,
            additionalUVCount: g[1], vertexIndexSize: g[2],
            textureIndexSize: g[3], materialIndexSize: g[4],
            boneIndexSize: g[5], morphIndexSize: g[6],
            rigidBodyIndexSize: g[7],
            nameJP: try c.string(encoding: encoding),
            nameEN: try c.string(encoding: encoding),
            commentJP: try c.string(encoding: encoding),
            commentEN: try c.string(encoding: encoding)
        )

        let vertexCount = try count(&c, maximum: 5_000_000)
        var vertices: [PMXVertex] = []
        vertices.reserveCapacity(vertexCount)
        for _ in 0..<vertexCount {
            let position = try c.vec3()
            let normal = try c.vec3()
            let uv = try c.vec2()
            for _ in 0..<Int(header.additionalUVCount) { _ = try c.vec4() }
            let weightType = try c.u8()
            switch weightType {
            case 0:
                _ = try c.index(size: header.boneIndexSize, signed: true)
            case 1:
                _ = try c.index(size: header.boneIndexSize, signed: true)
                _ = try c.index(size: header.boneIndexSize, signed: true)
                _ = try c.f32()
            case 2, 4:
                for _ in 0..<4 { _ = try c.index(size: header.boneIndexSize, signed: true) }
                for _ in 0..<4 { _ = try c.f32() }
                if weightType == 4 {
                    _ = try c.vec3(); _ = try c.vec3(); _ = try c.vec3()
                }
            case 3:
                _ = try c.index(size: header.boneIndexSize, signed: true)
                _ = try c.index(size: header.boneIndexSize, signed: true)
                _ = try c.f32()
                _ = try c.vec3(); _ = try c.vec3(); _ = try c.vec3()
            default:
                throw PMXReadError.invalidHeader
            }
            let edge = try c.f32()
            vertices.append(PMXVertex(position: position, normal: normal, uv: uv, edgeScale: edge))
        }

        let indexCount = try count(&c, maximum: 30_000_000)
        guard indexCount.isMultiple(of: 3) else { throw PMXReadError.invalidHeader }
        var indices: [UInt32] = []
        indices.reserveCapacity(indexCount)
        for _ in 0..<indexCount {
            let i = try c.index(size: header.vertexIndexSize)
            guard i >= 0, i < vertexCount else { throw PMXReadError.invalidHeader }
            indices.append(UInt32(i))
        }

        let textureCount = try count(&c, maximum: 1_000_000)
        var textures: [String] = []
        textures.reserveCapacity(textureCount)
        for _ in 0..<textureCount { textures.append(try c.string(encoding: encoding)) }

        let materialCount = try count(&c, maximum: 1_000_000)
        var materials: [PMXMaterial] = []
        materials.reserveCapacity(materialCount)
        for _ in 0..<materialCount {
            let nameJP = try c.string(encoding: encoding)
            let nameEN = try c.string(encoding: encoding)
            let diffuse = try c.vec4()
            let specular = try c.vec3()
            _ = try c.f32()
            let ambient = try c.vec3()
            let flags = try c.u8()
            _ = try c.vec4() // edge color
            _ = try c.f32()  // edge size
            let textureIndex = try c.index(size: header.textureIndexSize, signed: true)
            let sphereIndex = try c.index(size: header.textureIndexSize, signed: true)
            _ = try c.u8() // sphere mode
            let toonFlag = try c.u8()
            if toonFlag == 0 {
                _ = try c.index(size: header.textureIndexSize, signed: true)
            } else {
                _ = try c.u8()
            }
            _ = try c.string(encoding: encoding) // memo
            let surfaceCount = try c.i32()
            guard surfaceCount >= 0, surfaceCount % 3 == 0 else { throw PMXReadError.invalidHeader }
            materials.append(PMXMaterial(
                nameJP: nameJP, nameEN: nameEN, diffuse: diffuse,
                specular: specular, ambient: ambient, flags: flags,
                textureIndex: textureIndex, sphereTextureIndex: sphereIndex,
                surfaceCount: Int(surfaceCount)
            ))
        }

        return PMXModel(header: header, vertices: vertices, indices: indices,
                        textures: textures, materials: materials)
    }

    private static func count(_ c: inout PMXCursor, maximum: Int) throws -> Int {
        let n = try c.i32()
        guard n >= 0, Int(n) <= maximum else { throw PMXReadError.invalidHeader }
        return Int(n)
    }
}
