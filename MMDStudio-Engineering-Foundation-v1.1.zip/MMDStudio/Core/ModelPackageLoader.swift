import Foundation
import UIKit
import ZIPFoundation

struct LoadedModelPackage {
    let model: PMXModel
    let textures: [Int: UIImage]
    let pmxURL: URL
    let warnings: [String]
}

enum ModelPackageError: LocalizedError {
    case unsupportedType(String)
    case noPMXFound
    case unzipFailed(String)
    case readFailed(String)
    case parseFailed(String)

    var errorDescription: String? {
        switch self {
        case .unsupportedType(let ext):
            let suffix = ext.isEmpty ? "无扩展名" : ".\(ext)"
            return "不支持的文件类型（\(suffix)），请选择 .pmx、.zip 或模型文件夹。"
        case .noPMXFound:
            return "在所选内容中没有找到 .pmx 模型文件。"
        case .unzipFailed(let reason):
            return "压缩包解压失败：\(reason)"
        case .readFailed(let reason):
            return "读取模型失败：\(reason)"
        case .parseFailed(let reason):
            return "PMX 解析失败：\(reason)"
        }
    }
}

enum ModelPackageLoader {
    /// 支持三种入口：单个 .pmx、模型文件夹、包含模型的 .zip
    static func load(from url: URL) throws -> LoadedModelPackage {
        var root = url
        var temporaryDirectory: URL?

        let isDirectory = (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
        let ext = url.pathExtension.lowercased()

        if isDirectory {
            root = url
        } else if ext == "zip" {
            let destination = FileManager.default.temporaryDirectory
                .appendingPathComponent("MMDStudio-\(UUID().uuidString)", isDirectory: true)
            do {
                try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
                try FileManager.default.unzipItem(at: url, to: destination)
            } catch {
                throw ModelPackageError.unzipFailed(error.localizedDescription)
            }
            root = destination
            temporaryDirectory = destination
        } else if ext == "pmx" {
            // 单文件选择只能拿到这个文件的安全作用域；同级贴图可能读不到，仍然尝试
            root = url.deletingLastPathComponent()
        } else {
            throw ModelPackageError.unsupportedType(ext)
        }
        defer {
            if let temporaryDirectory {
                try? FileManager.default.removeItem(at: temporaryDirectory)
            }
        }

        let (pmxURL, pmxCandidates) = try findPMX(in: root)
        var warnings: [String] = []
        if pmxCandidates > 1 {
            warnings.append("发现 \(pmxCandidates) 个 PMX，已载入 \(pmxURL.lastPathComponent)")
        }

        let data: Data
        do {
            data = try Data(contentsOf: pmxURL, options: [.mappedIfSafe])
        } catch {
            throw ModelPackageError.readFailed(error.localizedDescription)
        }

        let model: PMXModel
        do {
            model = try PMXModelReader.read(data)
        } catch {
            throw ModelPackageError.parseFailed(error.localizedDescription)
        }

        let (textures, textureWarnings) = loadTextures(paths: model.textures,
                                                       baseDirectory: pmxURL.deletingLastPathComponent())
        warnings.append(contentsOf: textureWarnings)

        return LoadedModelPackage(model: model, textures: textures,
                                  pmxURL: pmxURL, warnings: warnings)
    }

    // MARK: - 查找 PMX

    private static func findPMX(in root: URL) throws -> (URL, Int) {
        let keys: [URLResourceKey] = [.isRegularFileKey]
        guard let enumerator = FileManager.default.enumerator(
            at: root,
            includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) else {
            throw ModelPackageError.noPMXFound
        }

        var candidates: [URL] = []
        for case let fileURL as URL in enumerator {
            guard fileURL.pathExtension.lowercased() == "pmx" else { continue }
            let isFile = (try? fileURL.resourceValues(forKeys: keys).isRegularFile) ?? false
            if isFile { candidates.append(fileURL) }
        }
        guard !candidates.isEmpty else { throw ModelPackageError.noPMXFound }

        candidates.sort { lhs, rhs in
            let ld = lhs.pathComponents.count
            let rd = rhs.pathComponents.count
            if ld != rd { return ld < rd }
            return lhs.lastPathComponent.localizedStandardCompare(rhs.lastPathComponent) == .orderedAscending
        }
        return (candidates[0], candidates.count)
    }

    // MARK: - 贴图

    private static func loadTextures(paths: [String], baseDirectory: URL) -> ([Int: UIImage], [String]) {
        guard !paths.isEmpty else { return ([:], []) }
        var warnings: [String] = []

        var byRelativePath: [String: URL] = [:]
        var byFileName: [String: URL] = [:]
        if let enumerator = FileManager.default.enumerator(
            at: baseDirectory,
            includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) {
            for case let fileURL as URL in enumerator {
                let isFile = (try? fileURL.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) ?? false
                guard isFile else { continue }
                let relative = fileURL.path.replacingOccurrences(of: baseDirectory.path + "/", with: "")
                let relativeKey = relative.precomposedStringWithCanonicalMapping.lowercased()
                let nameKey = fileURL.lastPathComponent.precomposedStringWithCanonicalMapping.lowercased()
                byRelativePath[relativeKey] = fileURL
                byFileName[nameKey] = fileURL
            }
        }

        var textures: [Int: UIImage] = [:]
        for (index, rawPath) in paths.enumerated() {
            guard !rawPath.isEmpty else { continue }
            let normalized = normalizeTexturePath(rawPath)
            let normalizedKey = normalized.precomposedStringWithCanonicalMapping.lowercased()
            let fileName = (normalized as NSString).lastPathComponent
                .precomposedStringWithCanonicalMapping.lowercased()

            var candidates: [URL] = [
                baseDirectory.appendingPathComponent(normalized)
            ]
            if let hit = byRelativePath[normalizedKey] { candidates.append(hit) }
            if let hit = byFileName[fileName] { candidates.append(hit) }
            candidates.append(baseDirectory.appendingPathComponent("tex").appendingPathComponent(fileName))
            candidates.append(baseDirectory.appendingPathComponent("texture").appendingPathComponent(fileName))

            var loaded: UIImage?
            for candidate in candidates {
                guard FileManager.default.fileExists(atPath: candidate.path) else { continue }
                if let data = try? Data(contentsOf: candidate),
                   let image = UIImage(data: data) {
                    loaded = image
                    break
                }
            }
            if let loaded {
                textures[index] = loaded
            } else {
                warnings.append("贴图缺失：\(rawPath)")
            }
        }
        return (textures, warnings)
    }

    /// PMX 里常见 Windows 反斜杠、盘符或前导 ./，统一成相对路径
    private static func normalizeTexturePath(_ path: String) -> String {
        var value = path.replacingOccurrences(of: "\\", with: "/")
        if let range = value.range(of: #"^[A-Za-z]:/"#, options: .regularExpression) {
            value.removeSubrange(range)
        }
        while value.hasPrefix("./") { value.removeFirst(2) }
        while value.hasPrefix("/") { value.removeFirst() }
        return value
    }
}
