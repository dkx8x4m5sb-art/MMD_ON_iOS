import Foundation

struct PMXHeader {
    let version: Float
    let encoding: UInt8
    let additionalUVCount: UInt8
    let vertexIndexSize: UInt8
    let textureIndexSize: UInt8
    let materialIndexSize: UInt8
    let boneIndexSize: UInt8
    let morphIndexSize: UInt8
    let rigidBodyIndexSize: UInt8
    let nameJP: String
    let nameEN: String
    let commentJP: String
    let commentEN: String

    var encodingDescription: String {
        encoding == 0 ? "UTF-16LE" : "UTF-8"
    }
}

enum PMXReadError: LocalizedError {
    case invalidSignature
    case unsupportedVersion(Float)
    case invalidHeader
    case truncatedData
    case invalidStringLength
    case invalidEncoding

    var errorDescription: String? {
        switch self {
        case .invalidSignature: return "The file does not have a PMX signature."
        case .unsupportedVersion(let v): return "Unsupported PMX version: \(v)."
        case .invalidHeader: return "The PMX global header is invalid."
        case .truncatedData: return "The PMX file ended unexpectedly."
        case .invalidStringLength: return "A PMX text field has an invalid length."
        case .invalidEncoding: return "The PMX text encoding is not supported."
        }
    }
}

private struct LittleEndianReader {
    let data: Data
    private(set) var offset = 0

    mutating func read<T: FixedWidthInteger>(_ type: T.Type = T.self) throws -> T {
        let size = MemoryLayout<T>.size
        guard offset + size <= data.count else { throw PMXReadError.truncatedData }
        var value: T = 0
        for i in 0..<size {
            value |= T(data[offset + i]) << T(i * 8)
        }
        offset += size
        return value
    }

    mutating func readFloat() throws -> Float {
        Float(bitPattern: try read(UInt32.self))
    }

    mutating func readBytes(count: Int) throws -> [UInt8] {
        guard count >= 0, offset + count <= data.count else {
            throw PMXReadError.truncatedData
        }
        let bytes = Array(data[offset..<(offset + count)])
        offset += count
        return bytes
    }

    mutating func readString(encoding: UInt8) throws -> String {
        let rawLength = try read(Int32.self)
        guard rawLength >= 0, rawLength <= 64 * 1024 * 1024 else {
            throw PMXReadError.invalidStringLength
        }
        let bytes = try readBytes(count: Int(rawLength))
        if encoding == 1 {
            guard let value = String(bytes: bytes, encoding: .utf8) else {
                throw PMXReadError.invalidEncoding
            }
            return value
        }
        guard encoding == 0, bytes.count.isMultiple(of: 2) else {
            throw PMXReadError.invalidEncoding
        }
        let units = stride(from: 0, to: bytes.count, by: 2).map {
            UInt16(bytes[$0]) | (UInt16(bytes[$0 + 1]) << 8)
        }
        return String(decoding: units, as: UTF16.self)
    }
}

enum PMXHeaderReader {
    static func read(from data: Data) throws -> PMXHeader {
        var reader = LittleEndianReader(data: data)

        let signature = try reader.readBytes(count: 4)
        guard signature == Array("PMX ".utf8) else {
            throw PMXReadError.invalidSignature
        }

        let version = try reader.readFloat()
        guard (abs(version - 2.0) < 0.01 || abs(version - 2.1) < 0.01) else {
            throw PMXReadError.unsupportedVersion(version)
        }

        let globalCount = Int(try reader.read(UInt8.self))
        guard globalCount == 8 else { throw PMXReadError.invalidHeader }
        let globals = try reader.readBytes(count: globalCount)
        let encoding = globals[0]
        guard encoding == 0 || encoding == 1 else {
            throw PMXReadError.invalidEncoding
        }

        let nameJP = try reader.readString(encoding: encoding)
        let nameEN = try reader.readString(encoding: encoding)
        let commentJP = try reader.readString(encoding: encoding)
        let commentEN = try reader.readString(encoding: encoding)

        return PMXHeader(
            version: version,
            encoding: encoding,
            additionalUVCount: globals[1],
            vertexIndexSize: globals[2],
            textureIndexSize: globals[3],
            materialIndexSize: globals[4],
            boneIndexSize: globals[5],
            morphIndexSize: globals[6],
            rigidBodyIndexSize: globals[7],
            nameJP: nameJP,
            nameEN: nameEN,
            commentJP: commentJP,
            commentEN: commentEN
        )
    }
}
