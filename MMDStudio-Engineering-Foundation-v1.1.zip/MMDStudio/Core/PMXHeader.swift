import Foundation

struct PMXHeader {
    let version: Float
    let encoding: UInt8
    let additionalUVCount: UInt8
    let vertexIndexSize: UInt8
    let textureIndexSize: UInt8
    let materialIndexSize: UInt8
    let boneIndexSize: UInt8
    let morphIndexSize: UInt8
    let rigidBodyIndexSize: UInt8
    let nameJP: String
    let nameEN: String
    let commentJP: String
    let commentEN: String

    var encodingDescription: String {
        encoding == 0 ? "UTF-16LE" : "UTF-8"
    }
}

enum PMXReadError: LocalizedError {
    case invalidSignature
    case unsupportedVersion(Float)
    case invalidHeader
    case truncatedData
    case invalidStringLength
    case invalidEncoding

    var errorDescription: String? {
        switch self {
        case .invalidSignature: return "该文件缺少 PMX 文件头标识。"
        case .unsupportedVersion(let v): return "不支持的 PMX 版本：\(v)。"
        case .invalidHeader: return "PMX 全局文件头无效。"
        case .truncatedData: return "PMX 文件数据意外结束。"
        case .invalidStringLength: return "PMX 文本字段长度无效。"
        case .invalidEncoding: return "不支持该 PMX 文本编码。"
        }
    }
}

