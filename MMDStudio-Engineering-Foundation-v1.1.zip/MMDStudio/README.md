# MMD Studio

Native iOS MMD model viewer and renderer foundation.

## Current scaffold
- SwiftUI application shell
- PMX header and model metadata reader (PMX 2.0/2.1 header section)
- `.pmx` file picker
- Metal preview surface
- XcodeGen project definition
- GitHub Actions workflow that builds an **unsigned** IPA artifact

This is the engineering foundation, not a finished MMD runtime. Full mesh/material import,
VMD/VPD, IK, Morph, physics, high-quality rendering, and PMX export are subsequent milestones.

## Requirements
- Xcode 16 or newer
- iOS deployment target: 17.0
- XcodeGen

## Generate and build locally
```bash
brew install xcodegen
xcodegen generate
xcodebuild -project MMDStudio.xcodeproj \
  -scheme MMDStudio \
  -sdk iphoneos \
  -configuration Release \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO
```

The resulting app is unsigned. Installing it on a physical iPhone requires an appropriate
signing and provisioning workflow.

## GitHub Actions
Push this project to GitHub. The workflow `.github/workflows/ios-build.yml` builds the app
and uploads an unsigned IPA artifact. Set up Apple signing separately if a signed IPA is needed.

## Format and compatibility notes
PMX is a binary little-endian format. The current reader validates the PMX signature,
reads the version/global settings, and extracts the four model text fields. It deliberately
does not claim to parse the complete model yet.

MMD Tools is used as a behavioral and compatibility reference only. This project scaffold
does not bundle its Python add-on or copy its implementation.


## Milestone 1.1 — geometry preview foundation
The reader now parses the PMX header, vertices (including supported weight-record layouts),
triangle indices, texture path strings, and material records. The Metal preview uploads vertex
and index buffers and draws a basic lit diagnostic mesh.

Known limitations:
- Bone, Morph, display-frame, rigid-body and joint sections are not yet parsed.
- Material texture images are not loaded or bound; the preview currently uses a diagnostic
  diffuse shader.
- Skinning, IK, physics, camera controls, production lighting, PMX export and VMD/VPD are not
  implemented yet.
- The PMX reader has not yet been validated against a broad corpus of real-world files.
