> 简体中文版：[README_zh.md](README_zh.md)

# MMD Studio — Test Build v1.1

MMD-focused iOS PMX geometry viewer foundation.

## What v1.1 test build includes
- SwiftUI iOS app shell (iOS 17+)
- PMX 2.0 / 2.1 header parsing
- Vertex and triangle index parsing
- BDEF1, BDEF2, BDEF4, SDEF and QDEF vertex-record skipping
- Texture path and material metadata parsing
- Import a single `.pmx`, a model folder, or a `.zip` containing the model
- Automatic PMX discovery inside a folder/ZIP, with texture loading from PMX relative paths
- Metal indexed-triangle rendering with per-material ranges and diffuse texture binding
- Drag to orbit and pinch / buttons to zoom
- GitHub Actions workflow to build an unsigned IPA artifact

## Not included in this test build
- Sphere maps (SPH/SPA) and Toon map compositing
- Texture formats unsupported by iOS ImageIO (e.g. TGA, DDS)
- Bone hierarchy and GPU skinning
- Morph animation
- VMD / VPD import and playback
- IK and MMD physics
- Camera/light editor
- Offline high-quality still rendering and MOV export
- PMX write-back/export

This is a **first geometry-viewer test build**, not yet a feature-complete MMD renderer. The parser currently stops after the material section; it does not yet parse the remaining PMX bone, morph, display-frame, rigid-body, and joint sections.

## Build with GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Push to `main` or `master`, or run the `MMDStudio Build` workflow manually.
3. Download the `MMDStudio-IPA` artifact from the workflow run.

The IPA is unsigned. Installing on a physical iPhone requires Apple code signing and provisioning. The workflow build must complete successfully on GitHub's macOS runner before treating the artifact as verified.

## Local build
Requires macOS, Xcode 16+, and XcodeGen:
```bash
brew install xcodegen
xcodegen generate
xcodebuild -project MMDStudio.xcodeproj \
  -scheme MMDStudio \
  -sdk iphoneos \
  -configuration Release \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO
```

## First device test
Use a small, known-good PMX 2.0/2.1 model. Keep the PMX and its `tex/` textures in one folder, or zip the whole folder and import it. **Prefer a folder or ZIP**: when a single `.pmx` is picked, iOS usually grants a security scope for that file only, so sibling textures may be unreadable. Test:
- Automatic PMX discovery after importing a folder/ZIP
- Model name and geometry counts
- Model and textures visible in the viewport
- Status line shows "textures N/M"; missing paths are logged
- Drag orbit and zoom controls
- Large model import memory behavior

## Project structure
- `App/`: SwiftUI application and import flow
- `Core/`: PMX data structures, binary parser, model package (folder/ZIP) loader
- `Renderer/`: Metal preview renderer and shader
- `.github/workflows/`: unsigned IPA build

Model package import uses [ZIPFoundation](https://github.com/weichsel/ZIPFoundation) (SPM dependency, 0.9.19+); the first build needs network access to resolve it.
