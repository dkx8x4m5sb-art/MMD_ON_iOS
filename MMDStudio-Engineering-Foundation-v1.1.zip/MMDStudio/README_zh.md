# MMD Studio — 测试版 v1.1

面向 MMD（MikuMikuDance）的 iOS PMX 几何预览工具基础版本。

## v1.1 测试版包含的功能

- SwiftUI iOS 应用外壳（iOS 17 及以上）
- PMX 2.0 / 2.1 文件头解析
- 顶点与三角面索引解析
- 支持跳过 BDEF1、BDEF2、BDEF4、SDEF、QDEF 五类顶点权重记录
- 纹理路径与材质元数据解析
- 支持导入单个 `.pmx`、模型文件夹或包含模型的 `.zip`
- 自动在文件夹/压缩包内定位 PMX，并按 PMX 记录的相对路径加载贴图
- 基于 Metal 的索引三角面渲染，按材质分段并绑定漫反射贴图
- 拖动旋转视角、双指捏合或按钮缩放
- GitHub Actions 工作流，可构建未签名 IPA 产物

## 本测试版未包含的功能

- 球面贴图（SPH/SPA）与 Toon 贴图合成
- iOS ImageIO 不支持的贴图格式（如 TGA、DDS）
- 骨骼层级与 GPU 蒙皮
- 表情（Morph）动画
- VMD / VPD 导入与播放
- IK 与 MMD 物理
- 相机与灯光编辑器
- 离线高质量静帧渲染与 MOV 导出
- PMX 回写导出

这是一个**仅用于几何预览的首版测试构建**，还不是功能完整的 MMD 渲染器。解析器目前读到材质段就停止，尚未解析 PMX 后续的骨骼、表情、显示枠、刚体与关节等段落。

## 使用 GitHub Actions 构建

1. 新建一个 GitHub 仓库，把本文件夹的内容上传上去。
2. 推送到 `main` 或 `master` 分支，或者手动运行 `MMDStudio Build` 工作流。
3. 在构建记录中下载名为 `MMDStudio-IPA` 的产物（未签名 IPA）。

该 IPA 未签名。要安装到实体 iPhone，需要苹果代码签名与描述文件（provisioning profile）。只有在 GitHub 的 macOS 运行器上成功完成构建后，才能把该产物视为已验证。

## 本地构建

需要 macOS、Xcode 16 及以上版本，以及 XcodeGen：

```bash
brew install xcodegen
xcodegen generate
xcodebuild -project MMDStudio.xcodeproj \
  -scheme MMDStudio \
  -sdk iphoneos \
  -configuration Release \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO
```

## 首次真机测试

请使用一个体积较小、确认可用的 PMX 2.0/2.1 模型。把 PMX 与 `tex/` 等贴图放在同一个文件夹，或直接打包成 `.zip` 后导入；**推荐选文件夹或压缩包**，因为单独选一个 `.pmx` 时，iOS 的安全作用域通常只覆盖该文件，同级贴图可能读不到。建议依次检查：

- 导入文件夹/压缩包后是否能自动找到 PMX
- 模型名称与几何数量是否正确
- 视口内是否能看到模型和贴图
- 状态栏是否显示「贴图 N/M」；缺失时日志中会有具体路径
- 拖动旋转与缩放按钮是否生效
- 导入大型模型时的内存表现

## 工程结构

- `App/`：SwiftUI 应用与导入流程
- `Core/`：PMX 数据结构、二进制解析器、模型包（文件夹/ZIP）加载
- `Renderer/`：Metal 预览渲染器与着色器
- `.github/workflows/`：未签名 IPA 构建

模型包导入使用 [ZIPFoundation](https://github.com/weichsel/ZIPFoundation)（SPM 依赖，版本 0.9.19 起），首次构建时需要网络解析依赖。

## 中文化说明

本目录是原项目的简体中文版：

- 界面文案、按钮提示、无障碍标签、状态栏与解析错误信息均已改为简体中文
- 模型名称仍读取 PMX 文件内的原始名称（`nameJP` 优先），不做翻译
- 代码标识符、日志级别、Metal 着色器函数名保持原样，避免影响构建

英文说明见 [README.md](README.md)。
